from pathlib import Path
import re

root = Path(__file__).resolve().parents[1]
tsv = root / "app/src/main/assets/gloss_ru.tsv"
if not tsv.exists():
    raise SystemExit("Missing gloss_ru.tsv")

rows = {}
for n, line in enumerate(tsv.read_text(encoding="utf-8").splitlines(), 1):
    if not line or line.startswith("#"):
        continue
    if "\t" not in line:
        raise SystemExit(f"Invalid TSV line {n}")
    key, value = line.split("\t", 1)
    if not key.strip() or not value.strip():
        raise SystemExit(f"Empty key/value on line {n}")
    if key in rows:
        raise SystemExit(f"Duplicate key on line {n}: {key}")
    rows[key] = value

required = [
    "hello", "good morning", "to eat", "Japan", "Japanese person",
    "I don't understand", "I am studying Japanese", "one", "twenty",
    "water", "rice", "tiger", "happy", "work", "study"
]
missing = [x for x in required if x not in rows]
if missing:
    raise SystemExit("Missing required Russian translations: " + ", ".join(missing))

# The Japanese vocabulary used by the main data set must be covered.
data = (root / "app/src/main/java/com/nexo/kotoba/Data.kt").read_text(encoding="utf-8")
english = []
for line in data.splitlines():
    if "Word(" not in line:
        continue
    quoted = re.findall(r'"((?:[^"\\]|\\.)*)"', line)
    if len(quoted) >= 6:
        english.append(quoted[5])
used = sorted(set(english))
covered = [x for x in used if x in rows]
coverage = len(covered) / max(1, len(used))
print(f"Russian glossary entries: {len(rows)}")
print(f"Main Data.kt English glosses: {len(used)}")
print(f"Direct Russian coverage: {len(covered)}/{len(used)} ({coverage:.1%})")
if coverage < 0.90:
    raise SystemExit("Russian vocabulary coverage is below 90%")

cyr = sum(1 for v in rows.values() if re.search(r"[А-Яа-яЁё]", v))
print(f"Entries containing Cyrillic: {cyr}/{len(rows)}")
print("Russian localization verification: PASS")
